-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Sep 17, 2018 at 02:16 PM
-- Server version: 5.0.41
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `zalego`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `customer`
-- 

CREATE TABLE `customer` (
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY  (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `customer`
-- 

INSERT INTO `customer` (`firstname`, `lastname`, `username`, `password`) VALUES 
('eugene', 'mutava', 'eugene1@gmail.com', '123456'),
('eugene', 'mutava', 'eugene@gmail.com', '123456'),
('eugene', 'mutava', 'eugenemuthini@gmail.', 'muthini'),
('eugene', 'muthini', 'muthini', '9999'),
('mutua', 'mutava', 'mutua@gmail.com', 'mutua'),
('eugene', 'mutava', 'password', 'password');
